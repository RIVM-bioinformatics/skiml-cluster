# SPDX-FileCopyrightText: 2023-present boasvdp <ids-bioinformatics@rivm.nl>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.2"
